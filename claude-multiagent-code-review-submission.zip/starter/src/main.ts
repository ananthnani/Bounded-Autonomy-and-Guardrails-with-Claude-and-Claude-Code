import * as dotenv from 'dotenv';
import { CodeReviewOrchestrator } from './orchestrator';
import { ReportGenerator } from './utils/report-generator';
import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { logger } from './utils/logger';
import { formatError } from './utils/error-handler';

// Load environment variables
dotenv.config();

/**
 * Main entry point for the Claude Multi-Agent Code Review System
 * Usage: npm run dev <owner> <repo> <pr-number>
 */
async function main() {
  const [owner, repo, prStr] = process.argv.slice(2);
  
  if (!owner || !repo || !prStr) {
    console.error('Usage: npm run dev <owner> <repo> <pr-number>');
    process.exit(1);
  }

  const prNumber = Number(prStr);
  if (!Number.isInteger(prNumber) || prNumber <= 0) {
    console.error('Error: PR number must be a positive integer.');
    process.exit(1);
  }
  
  const useBedrock =
  !!process.env.AWS_ACCESS_KEY_ID &&
  !!process.env.AWS_SECRET_ACCESS_KEY;
  
  const useAnthropic = !!process.env.ANTHROPIC_API_KEY;
  
  if (useBedrock) {
    if (!process.env.AWS_REGION) {
      console.error('Error: AWS_REGION is required for Bedrock.');
      process.exit(1);
    }

    console.log('🔐 Using AWS Bedrock authentication');
  } else if (useAnthropic) {
    console.log('🔐 Using Anthropic API authentication');
  } else {
    console.error(
      'Authentication missing. Configure ANTHROPIC_API_KEY or AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY.'
    );
    process.exit(1);
  }

  // TODO: Validate command line arguments
  // - Check if owner, repo, and prStr are provided
  // - Convert prStr to number and validate it's a valid integer
  // - Exit with error message if validation fails

  if (!process.env.ANTHROPIC_MODEL) {
    console.error('Error: ANTHROPIC_MODEL environment variable is required.');
    process.exit(1);
  }
  
  console.log('Using model:', process.env.ANTHROPIC_MODEL);

  console.log('start here', owner, repo, prStr)
  try {
    const orchestrator = new CodeReviewOrchestrator({
      model: process.env.ANTHROPIC_MODEL
    });

    logger.info('Starting code review', {
      owner,
      repo,
      prNumber
    });

    const report = await orchestrator.reviewPullRequest(
      owner,
      repo,
      prNumber
    );

    console.log('Review completed successfully.');
    console.log('Files analyzed:', report.summary.totalFiles);
    console.log('Overall score:', report.summary.overallScore);
    const reportGenerator = new ReportGenerator();

    const reportsDir = path.join(process.cwd(), 'reports');
    await fs.mkdir(reportsDir, { recursive: true });

    const fileName = `${owner}-${repo}-pr-${prNumber}`;

    await fs.writeFile(
      path.join(reportsDir, `${fileName}.md`),
      reportGenerator.generateMarkdownReport(report)
    );

    await fs.writeFile(
      path.join(reportsDir, `${fileName}.html`),
      reportGenerator.generateHTMLReport(report)
    );

    await fs.writeFile(
      path.join(reportsDir, `${fileName}.json`),
      reportGenerator.generateJSONReport(report)
    );

    console.log('Reports saved successfully in:', reportsDir);
  } catch (error) {
    logger.error('Code review failed', {
      error: formatError(error)
    });

    console.error('Code review failed:', formatError(error));
    console.error('Try: npm run dev -- <owner> <repo> <pr-number>');

    process.exitCode = 1;
  }
}

main();
