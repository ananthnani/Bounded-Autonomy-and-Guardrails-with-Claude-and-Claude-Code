import { query } from '@anthropic-ai/claude-agent-sdk';
import type { Options } from '@anthropic-ai/claude-agent-sdk';

import { ReviewReport, ReviewReportSchema } from './types/report-types';
import {
  CodeQualityResultSchema,
  TestCoverageResultSchema,
  RefactoringSuggestionSchema,
  CodeQualityResultJSONSchema,
  TestCoverageResultJSONSchema,
  RefactoringSuggestionJSONSchema
} from './types/analysis-results';

import { codeQualityAnalyzer } from './agents/code-quality-analyzer';
import { testCoverageAnalyzer } from './agents/test-coverage-analyzer';
import { refactoringSuggester } from './agents/refactoring-suggester';

import { mcpServersConfig } from './config/mcp.config';
import { globalRateLimiter, withRateLimit } from './utils/rate-limiter';
import { withRetry } from './utils/error-handler';
import { logger } from './utils/logger';
import { ORCHESTRATOR_PROMPT } from './prompts';

/**
 * Orchestrator configuration options
 */
export interface OrchestratorOptions {
  model?: string;
  maxConcurrent?: number;
  requestsPerMinute?: number;
  tokensPerMinute?: number;
}

/**
 * Main Code Review Orchestrator
 * Coordinates subagents to analyze pull requests and generate comprehensive reports
 */
export class CodeReviewOrchestrator {
  private model: string;
  private rateLimiter = globalRateLimiter;
  private mcpServers = mcpServersConfig;


  constructor(options: OrchestratorOptions = {}) {
  this.model = options.model || process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5-20250929';

  if (options.maxConcurrent || options.requestsPerMinute || options.tokensPerMinute) {
    this.rateLimiter = globalRateLimiter;
  }

  logger.info('Code Review Orchestrator initialized', {
    model: this.model
  });
}

  /**
   * Review a pull request using parallel subagent analysis
   * @param owner - Repository owner
   * @param repo - Repository name
   * @param prNumber - Pull request number
   * @returns Complete review report
   */
    private async runAgent(
    agentName: string,
    agentPrompt: string,
    outputSchema: any
  ): Promise<unknown> {
    const options: Options = {
      model: this.model,
      mcpServers: this.mcpServers,
      tools: ['Task'],
      allowedTools: [
        'Task',
        'mcp__github__get_pull_request',
        'mcp__github__get_pull_request_files',
        'mcp__github__get_file_contents',
        'mcp__github__search_repositories'
      ],
      agents: {
        codeQualityAnalyzer: codeQualityAnalyzer,
        testCoverageAnalyzer: testCoverageAnalyzer,
        refactoringSuggester: refactoringSuggester
      },
      outputFormat: {
        type: 'json_schema',
        schema: outputSchema
      }
    };

    return withRetry(async () => {
      return withRateLimit(this.rateLimiter, async () => {
        const response = query({
          prompt: agentPrompt,
          options
        });
        console.log(`[${agentName}] Claude query started`);

        let result: unknown;

        for await (const message of response) {
          console.log(`[${agentName}] SDK message:`, message.type,'subtype' in message ? message.subtype : '');
          if (message.type === 'result') {
            console.log(`[${agentName}] Result details:`, JSON.stringify(message, null, 2));
            
            if (message.subtype === 'success') {
              result = message.structured_output;
            }
          }
        }

        if (!result) {
          throw new Error(`${agentName} returned no structured output`);
        }

        return result;
      });
    });
  }
  async reviewPullRequest(
    owner: string,
    repo: string,
    prNumber: number
  ): Promise<ReviewReport> {
    if (!owner || !repo || !Number.isInteger(prNumber) || prNumber <= 0) {
      throw new Error('Invalid pull request details');
    }

    const prompt = `${ORCHESTRATOR_PROMPT}
    Review pull request #${prNumber} in repository ${owner}/${repo}.
    Use the GitHub MCP tools to fetch the pull request details,changed file paths, and relevant file contents.
    Delegate the analysis to all three registered subagents using the Task tool:
    1. codeQualityAnalyzer
    2. testCoverageAnalyzer
    3. refactoringSuggester
    Ensure each subagent analyzes the actual changed files and relevant context.
    Do not invent findings, test files, or code.
    Return the structured result matching the requested JSON schema.`;
    
    logger.info('Starting pull request review', {
      owner,
      repo,
      prNumber
    });
        const startTime = Date.now();
        
        const [qualityResult, coverageResult, refactoringResult] =
        await Promise.all([
          this.runAgent('Code Quality Analyzer',`${prompt}\n\nAnalyze code quality and return JSON.`,
            CodeQualityResultJSONSchema
          ),
          this.runAgent(
            'Test Coverage Analyzer',
            `${prompt}\n\nAnalyze test coverage and return JSON.`,
            TestCoverageResultJSONSchema
          ),
          this.runAgent(
            'Refactoring Suggester',
            `${prompt}\n\nSuggest refactoring improvements and return JSON.`,
            RefactoringSuggestionSchema
          )
        ]);
        
        const quality = CodeQualityResultSchema.parse(qualityResult);
        const coverage = TestCoverageResultSchema.parse(coverageResult);
        const refactoring = RefactoringSuggestionSchema.parse(refactoringResult);
        const reportData = {
      pullRequest: {
        owner,
        repo,
        number: prNumber
      },
      fileReviews: [
        {
          file: quality.file,
          codeQuality: quality,
          testCoverage: coverage,
          refactorings: refactoring
        }
      ],
      summary: {
        totalFiles: 1,
        overallScore: quality.overallScore,
        criticalIssues: quality.issues.filter(
          issue => issue.severity === 'critical'
        ).length,
        highPriorityTests: coverage.untestedPaths.filter(
          path => path.priority === 'high' || path.priority === 'critical'
        ).length,
        refactoringOpportunities: refactoring.suggestions.length
      },
      recommendations: [],
      metadata: {
        analyzedAt: new Date().toISOString(),
        duration: Date.now() - startTime,
        agentVersions: {
          codeQuality: this.model,
          testCoverage: this.model,
          refactoring: this.model
        }
      }
    };
    const report = ReviewReportSchema.parse(reportData);
    logger.info('Pull request review completed', {
      owner,
      repo,
      prNumber,
      duration: report.metadata.duration
    });

    return report;
  }
}
