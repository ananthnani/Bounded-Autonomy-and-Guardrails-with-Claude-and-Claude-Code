import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { CODE_QUALITY_ANALYZER_PROMPT } from '../prompts';

export const codeQualityAnalyzer: AgentDefinition = {
  description:
    'Analyzes pull request code changes for bugs, security vulnerabilities, performance problems, maintainability, and coding style.',

  model: 'inherit',

  tools: ['Read', 'Grep', 'Glob', 'Bash', 'Skill'],

  prompt: `${CODE_QUALITY_ANALYZER_PROMPT}

Return your findings as valid JSON matching this structure:

{
  "file": "path/to/file",
  "issues": [
    {
      "line": 1,
      "severity": "high",
      "category": "security",
      "description": "Explain the issue.",
      "suggestion": "Explain how to fix it."
    }
  ],
  "overallScore": 85,
  "summary": "Brief assessment of code quality."
}

Rules:
- Severity must be critical, high, medium, low, or info.
- Category must be security, performance, maintainability, style, bug-risk, or best-practice.
- Score must be between 0 and 100.
- Do not invent issues.
- Use actual file paths and line numbers.
- If no issues exist, return an empty issues array.
- Focus on actionable findings.
`
};