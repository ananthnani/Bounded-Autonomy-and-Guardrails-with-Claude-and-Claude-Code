import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { REFACTORING_SUGGESTER_PROMPT } from '../prompts';

export const refactoringSuggester: AgentDefinition = {
  description:
    'Reviews changed code and recommends safe improvements to readability, maintainability, and design.',

  model: 'inherit',

  tools: ['Read', 'Grep', 'Glob', 'Bash', 'Skill'],

  prompt: `${REFACTORING_SUGGESTER_PROMPT}

Return valid JSON matching this structure:

{
  "file": "path/to/file",
  "suggestions": [
    {
      "type": "extract-function",
      "location": "functionName",
      "impact": "high",
      "description": "Explain the improvement.",
      "before": "Current code example",
      "after": "Suggested code example",
      "benefits": "Explain the benefits."
    }
  ],
  "summary": "Brief refactoring assessment."
}

Rules:
- Type must be extract-function, rename, modernize, simplify, or pattern-improvement.
- Impact must be low, medium, or high.
- Do not invent code or recommend unnecessary changes.
- Preserve existing functionality.
- Make suggestions practical and actionable.
`
};