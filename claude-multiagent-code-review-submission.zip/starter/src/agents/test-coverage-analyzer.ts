import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { TEST_COVERAGE_ANALYZER_PROMPT } from '../prompts';

export const testCoverageAnalyzer: AgentDefinition = {
  description:
    'Analyzes pull request changes to identify missing tests, untested code paths, and testing gaps.',

  model: 'inherit',

  tools: ['Read', 'Grep', 'Glob', 'Bash', 'Skill'],

  prompt: `${TEST_COVERAGE_ANALYZER_PROMPT}

Return valid JSON matching this structure:

{
  "file": "path/to/file",
  "hasTests": true,
  "testFiles": ["path/to/test.ts"],
  "untestedPaths": [
    {
      "type": "function",
      "location": "functionName",
      "priority": "high",
      "reasoning": "Explain why this needs testing.",
      "suggestedTest": "Describe the test to add."
    }
  ],
  "coverageEstimate": 80,
  "summary": "Brief testing assessment."
}

Rules:
- Type must be function, class, branch, or edge-case.
- Priority must be critical, high, medium, or low.
- Coverage estimate must be between 0 and 100.
- Never invent test files or test coverage.
- Distinguish existing tests from suggested tests.
- Be specific and actionable.
`
};