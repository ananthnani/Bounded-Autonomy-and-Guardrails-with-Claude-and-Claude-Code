import { describe, it, expect, vi } from 'vitest';
import {
  CodeQualityResultSchema,
  TestCoverageResultSchema,
  RefactoringSuggestionSchema
} from '../src/types/analysis-results';

import {
  withRetry,
  withTimeout,
  ReviewError,
  ErrorCodes
} from '../src/utils/error-handler';

import { RateLimiter } from '../src/utils/rate-limiter';

describe('Zod schema validation', () => {
  it('accepts valid code quality results', () => {
    const result = {
      file: 'src/example.ts',
      issues: [],
      overallScore: 90,
      summary: 'Good code quality.'
    };

    expect(CodeQualityResultSchema.safeParse(result).success).toBe(true);
  });

  it('rejects an invalid code quality score', () => {
    const result = {
      file: 'src/example.ts',
      issues: [],
      overallScore: 120,
      summary: 'Invalid score.'
    };

    expect(CodeQualityResultSchema.safeParse(result).success).toBe(false);
  });

  it('accepts valid test coverage results', () => {
    const result = {
      file: 'src/example.ts',
      hasTests: true,
      testFiles: ['tests/example.test.ts'],
      untestedPaths: [],
      coverageEstimate: 80,
      summary: 'Coverage assessment completed.'
    };

    expect(TestCoverageResultSchema.safeParse(result).success).toBe(true);
  });

  it('rejects an invalid test coverage estimate', () => {
    const result = {
      file: 'src/example.ts',
      hasTests: true,
      testFiles: [],
      untestedPaths: [],
      coverageEstimate: 150,
      summary: 'Invalid coverage.'
    };

    expect(TestCoverageResultSchema.safeParse(result).success).toBe(false);
  });

  it('accepts valid refactoring suggestions', () => {
    const result = {
      file: 'src/example.ts',
      suggestions: [
        {
          type: 'extract-function',
          location: 'calculateTotal',
          impact: 'high',
          description: 'Extract repeated logic.',
          before: 'Repeated code',
          after: 'Reusable function',
          benefits: 'Improves maintainability.'
        }
      ],
      summary: 'One improvement identified.'
    };

    expect(RefactoringSuggestionSchema.safeParse(result).success).toBe(true);
  });

  it('rejects an invalid refactoring type', () => {
    const result = {
      file: 'src/example.ts',
      suggestions: [
        {
          type: 'invalid-type',
          location: 'calculateTotal',
          impact: 'high',
          description: 'Example.',
          before: 'Old code',
          after: 'New code',
          benefits: 'Improvement.'
        }
      ],
      summary: 'Invalid suggestion.'
    };

    expect(RefactoringSuggestionSchema.safeParse(result).success).toBe(false);
  });
});

describe('withRetry', () => {
  it('returns the result when the operation succeeds', async () => {
    const operation = vi.fn().mockResolvedValue('success');

    await expect(withRetry(operation, 2, 0)).resolves.toBe('success');
    expect(operation).toHaveBeenCalledTimes(1);
  });

  it('retries after a failure and succeeds', async () => {
    vi.useFakeTimers();
    vi.spyOn(Math, 'random').mockReturnValue(0);

    try {
      const operation = vi.fn()
        .mockRejectedValueOnce(new Error('Temporary failure'))
        .mockResolvedValue('success');

      const resultPromise = withRetry(operation, 1, 0);

      await vi.runAllTimersAsync();

      await expect(resultPromise).resolves.toBe('success');
      expect(operation).toHaveBeenCalledTimes(2);
    } finally {
      vi.useRealTimers();
      vi.restoreAllMocks();
    }
  });

  it('throws RETRY_EXHAUSTED after all attempts fail', async () => {
    const operation = vi.fn().mockRejectedValue(new Error('Failure'));

    await expect(withRetry(operation, 0, 0)).rejects.toMatchObject({
      code: ErrorCodes.RETRY_EXHAUSTED
    });

    expect(operation).toHaveBeenCalledTimes(1);
  });
});

describe('withTimeout', () => {
  it('returns the result when the operation finishes in time', async () => {
    await expect(
      withTimeout(async () => 'completed', 1000)
    ).resolves.toBe('completed');
  });

  it('throws AGENT_TIMEOUT when the operation takes too long', async () => {
    await expect(
      withTimeout(
        () => new Promise<string>((resolve) => {
          setTimeout(() => resolve('late'), 100);
        }),
        10,
        'Test operation timed out'
      )
    ).rejects.toMatchObject({
      code: ErrorCodes.AGENT_TIMEOUT,
      message: 'Test operation timed out',
      metadata: { timeoutMs: 10 }
    });
  });
});

describe('RateLimiter', () => {
  it('tracks acquired requests and token usage', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 5,
      maxTokensPerMinute: 100,
      maxConcurrent: 2
    });

    const requestId = await limiter.acquire(40);
    const status = limiter.getStatus();

    expect(requestId).toBe(1);
    expect(status.activeRequests).toBe(1);
    expect(status.requestsInWindow).toBe(1);
    expect(status.tokensInWindow).toBe(40);

    limiter.release(requestId);
  });

  it('updates token usage when a request is released', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 5,
      maxTokensPerMinute: 100,
      maxConcurrent: 2
    });

    const requestId = await limiter.acquire(40);
    limiter.release(requestId, 25);

    expect(limiter.getStatus().tokensInWindow).toBe(25);
  });

  it('prevents requests when the concurrency limit is reached', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 5,
      maxTokensPerMinute: 100,
      maxConcurrent: 1
    });

    const requestId = await limiter.acquire(20);

    expect(limiter.canProceed(10)).toBe(false);

    limiter.release(requestId);

    expect(limiter.canProceed(10)).toBe(true);
  });

  it('prevents requests that exceed the token limit', () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 5,
      maxTokensPerMinute: 50,
      maxConcurrent: 2
    });

    expect(limiter.canProceed(60)).toBe(false);
  });
});
